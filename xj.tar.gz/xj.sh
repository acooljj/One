#!/bin/bash
#A=`free -m | sed -n '2p' | awk '{print "内存使用"$3/$2*100"%"}' && top -n 1| sed -n '3p' | awk '{print$2}'| awk -F "us" '{print"CPU使用"$1}' && df -h | awk '{print"硬盘目录:"$6"  ""使用率:"$5"  ""可使用空间:"$4}'|sed '1d' && top -n 1 | sed -n '1p'|awk -F ":" '{print"负载情况:"$5}' `
A=`free -m | sed -n '2p' | awk '{print "内存使用"$3/$2*100"%"}'`
B=`top -n 1| sed -n '3p' | awk '{print$2}'| awk -F "us" '{print"CPU使用"$1}'`
C=`df -h | awk '{print"硬盘目录:"$6"  ""使用率:"$5"  ""可使用空间:"$4}'|sed '1d'`
#C=`df -h`
D=`top -n 1 | sed -n '1p'|awk -F ":" '{print"负载情况:"$5}'`
echo $A > /root/xunj.txt
echo $B >> /root/xunj.txt
echo $C >> /root/xunj.txt
echo $D >> /root/xunj.txt

